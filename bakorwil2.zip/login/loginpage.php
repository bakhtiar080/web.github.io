<html>
<head>
<title>CPanel LOGIN - Bakorwil Bojonegoro</title>
<link rel="SHORTCUT ICON" href="http://www.bakorwilbojonegoro.jatimprov.go.id/favicon.ico">
<link href="../style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center"><img src="../images/jatim.png" width="100" height="141"/></p>
<p align="center">PEMERINTAHAN PROVINSI JAWA TIMUR </p>
<p align="center">BAKORWIL BOJONEGORO </p>
<table width="121" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
    <tr>
      <form name="form1" method="post" action="checklogin.php">
        <td>
          <table width="97%" border="0" align="left" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
              
            <tr>
              <td width="46">Username</td>
      <td width="90"><input name="myusername" type="text" id="myusername" size="20" style="font-family:tahoma;font-size:16px;"></td>
      </tr>
            <tr>
              <td>Password</td>
      <td><input name="mypassword" type="password" id="mypassword" size="20" style="font-family:tahoma;font-size:16px;"></td>
      </tr>
            <tr>
              <td>&nbsp;</td>
      <td><div align="right">
        <input name="Submit" type="submit" value="Login" style="font-family:tahoma;font-size:16px;">
        </div></td>
      </tr>
          </table>    </td>
      </form>
    </tr>
</table>
</body>
</html>