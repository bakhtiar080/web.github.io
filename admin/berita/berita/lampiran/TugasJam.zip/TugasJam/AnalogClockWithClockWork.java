package TugasJam;

import java.util.Calendar;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.text.*;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.sound.midi.Patch;

public class AnalogClockWithClockWork extends Application{
    static final double unit = 200.0;
    private ClockWork clockWork = new ClockWork();
    
    private Node hourHand(){
        Rotate rotate = rotationAuronCenter();
        rotate.angleProperty().bind(clockWork.hour.multiply(360 / 12).add(clockWork.hour.multiply(360 / 12 / 60)));
        return hand(unit * 0.4, Color.BLACK, rotate);
    }
    
    private Node minuteHand(){
        Rotate rotate = rotationAuronCenter();
        rotate.angleProperty().bind(clockWork.minute.multiply(360 / 60));
        return hand(unit * 0.2, Color.BLACK, rotate);
    }
    
    private Node secondHand(){
        Rotate rotate = rotationAuronCenter();
        rotate.angleProperty().bind(clockWork.second.multiply(360 / 60));
        Line line = new Line(unit, unit, unit, unit * 0.2);
        line.getTransforms().add(rotate);
        return line;
    }
    
    private Rotate rotationAuronCenter(){
        return new Rotate(0.0, unit, unit);
    }
    
    private Node hand(double stretchRelativeToRim, Color color, Rotate rotate){
        Path path = new Path(
                new MoveTo(unit, unit),
                new LineTo(unit * 0.9, unit * 0.9),
                new LineTo(unit, stretchRelativeToRim),
                new LineTo(unit * 1.1, unit * 0.9),
                new LineTo(unit, unit)
        );
        path.setFill(color);
        path.setStroke(Color.TRANSPARENT);
        path.getTransforms().add(rotate);
        return path;
    }
    
    private Node tickMarks(){
        Group tickMarkGroub = new Group();
        for (int i = 0; i < 60; i++) {
            tickMarkGroub.getChildren().add(tickMark(i));
        }
        return tickMarkGroub;
    }
    
    private Node tickMark(int n){
        double angle = 360 / 60 * n;
        Rotate rotate = new Rotate(angle, unit, unit);
        Line line = new Line(unit, unit * 0.12, unit, unit * (n % 5 == 0 ? 0.3 : 0.2));
        line.getTransforms().add(rotate);
        return line;        
    }
    
    private Node centerPoint(){
        double radius = 0.05 * unit;
        return new Circle(unit, unit, radius, Color.BLACK);
    }
    
    private Node outerRim(){
        Circle lingkaran = new Circle(unit, unit, unit, Color.TRANSPARENT);
        lingkaran.setStroke(Color.BLACK);
        return lingkaran;
    }
    
    private Text text(){
        Text jam = new Text();
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            Calendar time = Calendar.getInstance();
            jam.setText(time.get(Calendar.HOUR)+" : "+time.get(Calendar.MINUTE)+" : "+time.get(Calendar.SECOND)+ " "+(Calendar.AM_PM == Calendar.AM ? "AM" : "PM"));
            jam.setX(230);
            jam.setY(unit*2.5/2-20);
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        return jam;
    }
    
    @Override
    public void start(Stage primaryStage) {
        Parent analog = new Group(
                outerRim(),
                minuteHand(),
                hourHand(),
                secondHand(),
                tickMarks(),
                centerPoint(),
                text()
        );
        StackPane root2 = new StackPane();
        root2.getChildren().add(analog);
        Scene scene = new Scene(root2, unit * 5, unit * 2.5);
        primaryStage.setTitle("Digital Clock");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
