package TugasJam;

import java.util.Calendar;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.util.Duration;

public class ClockWork {
    public SimpleIntegerProperty hour = new SimpleIntegerProperty(0);
    public SimpleIntegerProperty minute = new SimpleIntegerProperty(0);
    public SimpleIntegerProperty second = new SimpleIntegerProperty(0);
    
    public ClockWork(){
        startTicking();
    }
    
    private void startTicking(){
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            Calendar calender = Calendar.getInstance();
            hour.set(calender.get(Calendar.HOUR));
            minute.set(calender.get(Calendar.MINUTE));
            second.set(calender.get(Calendar.SECOND));
        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

}
