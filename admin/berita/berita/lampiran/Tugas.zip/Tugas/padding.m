function [arrayoutput] = padding (gambar, xy, tipe)
    if(tipe == 'zeros')
        xPad = xy(1,1);
        yPad = xy(1,2);
        [xG yG] = size(gambar);
        arrayoutput=zeros(xG+xPad+xPad, yG+yPad+yPad);
        indeks=1;
        i=xPad+1;
        j=yPad+1;
        ig=1;
        jg=1;
        while(indeks<=(xG*yG))
            arrayoutput(i,j)=gambar(ig,jg);
            if(yG~=jg)
                jg=jg+1;
                j = j+1;
            elseif(yG == jg)
                jg=1;
                j = yPad+1;
                ig=ig+1;
                i = i+1;
            elseif(yG==jg && xG==ig)
                break;
        end
            indeks=indeks+1;
        end
    elseif(tipe == 'reflection')
        
    elseif(tipe == 'replicate')
        
    end
end