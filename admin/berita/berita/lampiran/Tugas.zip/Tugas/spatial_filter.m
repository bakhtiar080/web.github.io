function gambar_baru = spatial_filter(gambar_orisinil, topeng)
  % ambil ukuran topeng
  [y_topeng x_topeng] = size(topeng);
  setengah_topeng = [floor(y_topeng/2) floor(x_topeng/2)];
  % gambar_orisinilnya harus dibesarkan dulu
  ukuran_orisinil = size(gambar_orisinil);
  gambar_orisinil = padding(gambar_orisinil, setengah_topeng, 'zeros');
  % function padding disini dari function padding yang sebelumnya dibuat
  % buat gambar baru dengan ukuran sama dengan gambar orisinil
  gambar_baru = zeros(size(gambar_orisinil));
  % setelah itu, jalankan topengnya dari pojok kiri atas gambar,
  % sampai ke pojok kanan bawah gambar
  for y = 1 : ukuran_orisinil(1)
    for x = 1 : ukuran_orisinil(2)
      % setelah topengnya ditempatkan pada posisi gambar (y,x), maka
      % ubah nilai gambar pada lokasi tengah topeng dengan hasil 
      % gambar asli dikali dengan nilai pada topeng
      nilai_pixel_baru = 0;
      %fprintf(strcat("y, x = ", int2str(y), ", ", int2str(x), "\n"))
      for k = 1 : size(topeng)(1)
        for j = 1 : size(topeng)(2)
          %fprintf(strcat("k, j = ", int2str(k), ", ", int2str(j), "\n"))
          nilai_pixel_awal = gambar_orisinil(y + k - 1, x + j - 1);
          nilai_pixel_baru += nilai_pixel_awal * topeng(k, j);
        end
      end
      % setelah dapat, sekarang kita replace nilai pixel gambar asli yang
      % bertepatan dengan titik tengahnya topeng
      y_tengah = y + setengah_topeng(1);
      x_tengah = x + setengah_topeng(2);
      gambar_baru(y_tengah, x_tengah) = nilai_pixel_baru;
    end
  end
  
  gambar_baru = uint8(gambar_baru);
end